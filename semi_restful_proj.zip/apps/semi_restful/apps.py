from django.apps import AppConfig


class SemiRestfulConfig(AppConfig):
    name = 'semi_restful'
